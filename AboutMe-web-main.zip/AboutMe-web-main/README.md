# AboutMe-web.

## Description

This is a personal portfolio website created to showcase my skills, projects, and services as a student developer.  
The website includes sections for an introduction, services, and contact information.

The project was built using only HTML and CSS with a responsive and modern design.

## Features

- Responsive landing page
- Fixed navigation bar
- Background image section
- Services cards section
- Contact section
- Smooth scrolling effect
- Hover animations


## project image: <img width="949" height="440" alt="22" src="https://github.com/user-attachments/assets/56359cd2-5dd7-4028-9e86-653ae98e021d" />


## Technologies Used

- HTML5
- CSS3
- Font Awesome
- Google Fonts

## Project Structure

text
project-folder/
│
├── index.html
├── style.css
└── images/
    └── background.jpg

## Author: Mohamed Mahany
